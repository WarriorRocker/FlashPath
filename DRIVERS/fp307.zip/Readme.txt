FlashPath Floppy Disk Adapter Readme Notes
_______________________________
Ver. 3.07.02

January 01,2001

* INTRODUCTION

This file contains late-breaking information about the FlashPath setup disk.

Please read this file before using the FlashPath Floppy Disk Adapter
(here after FlashPath adapter).


=== Table of Contents ===========

This document contains the following sections:

NOTES
     System Requirements
     Acceptable SmartMedia
     Systems Incompatible with the FlashPath Adapter
     Startup Disk
     Uninstall of Old FlashPath Driver
     Usage and Battery Life
     Battery Life at Low Temperatures
     Precautions Regarding the FlashPath Driver
     Handling Precautions
     Precautions with the Batteries
TROUBLESHOOTING
     "The Disk in Drive A Is Not Formatted" Appeared When Any Access Is Made
          5 Minutes or More
     FlashPath Adapter Not Detected
     SmartMedia Memory Card Will Not Format
     Write Protection Is Not Effective Even with a Write-Protect Pad Affixed to
          the SmartMedia Memory Card 
     The Status Monitor Disappeared from the Taskbar
     How to Delete the Status Monitor from the Start Menu
     Writing to the FlashPath Adapter Is Relatively Slower than Reading from It
WARNINGS
=== NOTES =================
OPERATION IS CHECKED ON THE FOLLOWING HARDWARES AND OPERATING SYSTEMS

* SYSTEM REQUIREMENT
    Operating system :	Microsoft Windows 95/98/Me (English)
    Hardware	 :	IBM PC/AT compatible
    CPU		 :	486DX or greater processor
    RAM		 :	16MB or more

* ACCEPTABLE SMARTMEDIA  
    Capacity :   2/4/8/16/32/64MB(FS-B10),2/4/8/16/32MB(FS-A10) 
    Voltage	 :   3.3V only	


* SYSTEMS INCOMPATIBLE WITH THE FLASHPATH ADAPTER

The FlashPath adapter cannot be used with devices connected to the computer 
with non-standard floppy disk drive interfaces.

Examples include:
  - External floppy disk drives connected via a PC card;
  - 120 MB and other high-capacity floppy disk drives.


The FlashPath adapter cannot be used with a high-capacity floppy disk drive
that exceeds 1.4MB or with a floppy disk connected via a PC card and USB interface.

Examples include:
  - Floppy disk drives that support 2.88 MB data storage.

* STARTUP DISK 

The FlashPath adapter cannot be utilized as a startup disk. Please use the 
internal hard disk drive or a standard floppy disk as the startup disk.
Insert the FlashPath adapter into the floppy disk drive only after 
Windows(r) 95/98/Me is running.

* USAGE AND BATTERY LIFE

The FlashPath adapter consumes more battery charge when it is writing data 
than when it is reading. Extensive data writing will shorten the battery life.


* BATTERY LIFE AT LOW TEMPERATURES

Battery life will generally be shortened when used at low temperatures.


* PRECAUTIONS REGARDING THE FLASHPATH DRIVER

Never eject the FlashPath adapter from the floppy disk drive while it is being
formatted with the FlashPath Format utility. The SmartMedia memory card may 
become unusable or may not format correctly if prematurely ejected.

Never eject the FlashPath adapter from the floppy disk drive during a write 
operation. The SmartMedia memory card may become unusable or the write operation
may fail.

The status monitor may not reflect the FlashPath adapter status without starting
it prior to FlashPath loading. To accurately reflect the FlashPath adapter
contents in the status monitor, eject the FlashPath adapter from the floppy 
disk drive, start the status monitor first and then reinsert the FlashPath adapter.

If an application program causes an error during a read/write operation, 
check the status of the FlashPath adapter in the status monitor.

* HANDLING PRECAUTIONS

Protect the FlashPath adapter when it is not in use by storing it 
in the case provided.

Be particularly careful when inserting and removing SmartMedia memory 
cards.

To insert the SmartMedia memory card, ensure that its contact surface is 
facing the side opposite to the metallic cover of the adapter.

Always eject the FlashPath adapter from the floppy disk drive when not in use.

Leave the FlashPath adapter in the floppy disk drive only while it is in active use.

To prevent damage to the FlashPath adapter:
  - Do not bend, fold or twist it;
  - Do not drop it;
  - Avoid storing it in areas subject to high temperatures or humidity;
  - Avoid storing it in areas subject to condensation.


* PRECAUTIONS WITH THE BATTERIES

Always change both CR2016 lithium batteries at the same time when one or both 
expire. Also, be sure that the positive (+) terminal faces up.

To maximize the battery life, eject the FlashPath adapter from the floppy disk 
drive as soon as you finish actively using it. The FlashPath adapter power turns 
off when ejected from the floppy disk drive, reducing the drain on the batteries.

When the status monitor indicates a low battery charge, only read operations can 
be performed until the batteries are replaced. Replace the batteries
as soon as possible.

When the status monitor indicates a low battery charge, writing data to the 
SmartMedia memory card may become physically impossible. Although an application
such as Microsoft Word 95 may indicate that a write operation was successful 
after the low battery indicator lights, there is a strong chance that the file
was not written to the SmartMedia memory card.


=== TROUBLESHOOTING =========
*"THE DISK IN DRIVE A IS NOT FORMATTED" APPEARED WHEN ANY ACCESS IS MADE 5
MINUTES OR MORE 

FlashPath adapter is in shut-down mode.If the FlashPath adapter is in shut-down
mode, reset it by ejecting and reinserting it into the floppy disk drive.

* FLASHPATH ADAPTER NOT DETECTED

The FlashPath adapter may occasionally be incompletely recognized by the computer,
causing a message similar to "The disk in drive A is not formatted. Do you want 
to format it now?" to appear when you attempt to access the FlashPath adapter. 
In most cases, ejecting and reinserting the FlashPath adapter will solve this problem. 

The same phenomenon may occur if:

  - the FlashPath adapter has been inserted into the floppy disk drive, left
    unaccessed for more than five minutes and entered shut-down mode;
  - the batteries are missing or virtually chargeless;
  - the batteries are incorrectly installed (the positive (+) terminals should face up);
  - the FlashPath driver is not correctly installed on the computer (be sure to restart 
    the computer after installing the driver software).


* SMARTMEDIA MEMORY CARD WILL NOT FORMAT

A SmartMedia memory card in the FlashPath adapter cannot be formatted with the 
Windows [Format] command in the [File] menu of the [My Computer] window. 

To format the SmartMedia memory card, use the format feature on your digital 
camera or format it with the FlashPath adapter by clicking the [Start] button 
on the Windows taskbar and selecting [Programs], [FlashPath] and [FlashPath Format] 
in succession.


* WRITE PROTECTION IS NOT EFFECTIVE EVEN WITH A WRITE-PROTECT PAD AFFIXED TO 
  THE SMARTMEDIA MEMORY CARD 

The FlashPath adapter does not detect the write-protect pads affixed to SmartMedia
memory cards. Be careful not to overwrite or mistakenly erase data. 


* THE STATUS MONITOR DISAPPEARED FROM THE TASKBAR

To restart the status monitor program, click the [Start] button on the Windows 
taskbar and select [Programs], [FlashPath] and [FlashPath Status] in succession. 
(The status of a FlashPath adapter that has already been accessed before starting
 the status monitor may not be accurately reflected: see "Precautions Regarding the
 FlashPath Driver" above.)


* HOW TO DELETE THE STATUS MONITOR FROM THE START MENU

The status monitor program is automatically registered in the Windows start
menu when the FlashPath driver software is installed. To delete it,
open the Windows Explorer window and select the [Windows], [Start Menu], 
[Programs] and [Startup] folders. Delete the [FlashPath Status] icon from 
the Startup folder. 

To start the status monitor after its icon is deleted from the Startup folder, 
click the [Start] button on the Windows taskbar and select [Programs], 
[FlashPath] and [FlashPath Status] in succession.
(The status of a FlashPath adapter that has already been accessed before 
starting the status monitor may not be accurately reflected: see "Precautions
Regarding the FlashPath Driver" above.)


* WRITING TO FLASHPATH IS RELATIVELY SLOWER THAN READING FROM IT

There is no malfunction if writing data takes twice as long as reading it. 
In contrast to standard floppy disks, the FlashPath adapter communicates with
driver software each time it reads or writes data in order to exchange files 
with the SmartMedia memory card. Since the read and write processes are different,
the time requirements differ. Writing requires approximately twice as long as reading.


=== WARNINGS =========

* The manufacturer is not responsible for any damages arising from the use or
  application of this software and its manuals.
* The contents of this software and its manuals are subject to change without
  notice.
* All the company and product names listed herein are the trademarks or registered
  trademarks of their respective owners.
